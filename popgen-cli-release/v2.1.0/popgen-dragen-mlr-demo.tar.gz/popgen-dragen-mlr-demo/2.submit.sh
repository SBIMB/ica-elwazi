#!/bin/bash

set -eo pipefail

project_config_json=$(ls project-data/secret/*.json | tail -n1)
output_analysis_folder="output_analysis_folder"
project_name=$(cat $project_config_json | jq -r .ica_job_project.name)
output_project_name=$(echo $project_name | sed 's|-jobs$|-output|g')
analysis_instance_tier=economy
region=euc1

function submit () {

  job_line=$1
  
  input_sample_id=$(echo $job_line | cut -d\, -f1)
  input_align_file_url=$(echo $job_line | cut -d\, -f2)
  input_gvcf_file_url=$(echo $job_line | cut -d\, -f3)

  run_id=$(date +%Y%m%d%H%M%S)
  input_ht_folder_url=ica://$region-popgen-cli-release-demo/data/ref/hashtable/hg38_alt_masked_graph_v2/DRAGEN/9
  output_folder_url=ica://$output_project_name/data/dragen-mlr-sample-$input_sample_id-run-$run_id

  popgen-cli dragen-mlr submit \
      --input-project-config-file-path $project_config_json \
      --output-analysis-json-folder-path $output_analysis_folder \
      --run-id $run_id \
      --sample-id $input_sample_id \
      --input-ht-folder-url $input_ht_folder_url \
      --output-folder-url $output_folder_url \
      --input-align-file-url $input_align_file_url \
      --input-gvcf-file-url $input_gvcf_file_url \
      --analysis-instance-tier $analysis_instance_tier

}

for line in $(cat input.csv); do
    submit $line
done

