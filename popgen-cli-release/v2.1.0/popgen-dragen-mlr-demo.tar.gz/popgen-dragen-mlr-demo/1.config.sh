#!/bin/bash

popgen-cli dragen-mlr config


