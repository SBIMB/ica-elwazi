#!/bin/bash

popgen-cli dragen-igg config


