#!/usr/bin/env cwl-runner

cwlVersion: v1.0
class: CommandLineTool
baseCommand: runner.sh
arguments:
- dragen-igg-runner

hints:
  DockerRequirement:
    dockerPull: __PIPELINE_DOCKER_IMAGE__

requirements:
  EnvVarRequirement:
    envDef:
      TMPDIR: "/scratch"

inputs:
  job_def_str:
    type: string
    inputBinding:
      position: 1
      prefix: --job-def-str
  job_secret_file:
    type: File
    inputBinding:
      position: 2
      prefix: --job-secret-file

outputs:
  standard_out:
    type: stdout
  standard_err:
    type: stderr

stdout: stdout.txt
stderr: stderr.txt

temporaryFailCodes: [ 1, 55 ]
