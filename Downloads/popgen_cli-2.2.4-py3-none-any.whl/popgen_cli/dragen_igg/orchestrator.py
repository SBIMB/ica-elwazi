"""Orchestrate the DRAGEN-IGG demo end to end.

This automates the procedure that demo/dragen-igg/{1.config.sh,2.upload.sh,
3.submit.sh,poll.sh} performs by hand. It does not change the workload: every
analysis is submitted through popgen_cli.dragen_igg.submit with the same step
names and the same demo parameters, so the science is identical to the manual
demo.

Two commands:

    popgen-cli dragen-igg setup --region ape2     # one-time, non-interactive
    popgen-cli dragen-igg demo                    # runs and supervises

"setup" is the non-interactive equivalent of "popgen-cli dragen-igg config",
which remains available and unchanged for users who want the interactive Q&A.
"""

from __future__ import annotations

import argparse
import csv
import datetime
import getpass
import json
import os
import re
import shutil
import string
import sys
import time

import popgen_cli.dragen_igg.submit as submit
import popgen_cli.utils.utils as utils


# ------- managed project identity -------

MANAGED_TAG_NAMESPACE = 'popgen-cli'
MANAGED_TAG_MANAGED = f'{MANAGED_TAG_NAMESPACE}:managed=true'
SUPPORTED_PURPOSE_LIST = ['demo', 'smoke', 'test', 'customer']
WORKFLOW_NAME = 'dragen-igg'
REQUIRED_MANIFEST_COLUMNS = ('sample_id', 'gvcf', 'gvcf_index', 'sex')

# ICA project names must be 8-64 chars of [a-z0-9-], start with a letter and end
# with "-jobs" (ICAConfig._name_is_valid). submit.py derives the sibling project
# names by removing that suffix, so it has to stay.
MANAGED_NAME_SUFFIX = '-jobs'


def managed_project_name(region_short_name, purpose, date_str, run_id):
    """e.g. ape2-igg-demo-20260921-0001-jobs"""
    return f'{region_short_name}-igg-{purpose}-{date_str}-{run_id}{MANAGED_NAME_SUFFIX}'


def managed_technical_tags(purpose, region_short_name, run_id, version):
    return [
        MANAGED_TAG_MANAGED,
        f'{MANAGED_TAG_NAMESPACE}:workflow={WORKFLOW_NAME}',
        f'{MANAGED_TAG_NAMESPACE}:purpose={purpose}',
        f'{MANAGED_TAG_NAMESPACE}:region={region_short_name}',
        f'{MANAGED_TAG_NAMESPACE}:run-id={run_id}',
        f'{MANAGED_TAG_NAMESPACE}:version={version}',
    ]


def is_managed_project(project_details, purpose=None, region_short_name=None):
    """A project is managed only if BOTH its technical tags and its name say so.

    A name match alone is never sufficient: a customer project that happens to
    share a prefix must never be selected by automation.
    """
    if project_details == None:
        return False
    name = project_details.get('name', '')
    if not name.endswith(MANAGED_NAME_SUFFIX):
        return False
    tags = (project_details.get('tags') or {}).get('technicalTags') or []
    if MANAGED_TAG_MANAGED not in tags:
        return False
    if f'{MANAGED_TAG_NAMESPACE}:workflow={WORKFLOW_NAME}' not in tags:
        return False
    if purpose and f'{MANAGED_TAG_NAMESPACE}:purpose={purpose}' not in tags:
        return False
    if region_short_name and f'{MANAGED_TAG_NAMESPACE}:region={region_short_name}' not in tags:
        return False
    return True


def find_managed_projects(ica_client, purpose=None, region_short_name=None):
    return [p for p in ica_client.get_projects()
            if is_managed_project(p, purpose=purpose, region_short_name=region_short_name)]


# ------- stage plan -------

class Stage:
    """One logical step of the demo.

    kind == 'analysis': submits ICA analyses and waits for all of them.
    kind == 'local':    runs locally, submits nothing (count-subshards).
    """

    def __init__(self, name, kind, description):
        self.name = name
        self.kind = kind
        self.description = description

    def __repr__(self):
        return f'Stage({self.name!r}, {self.kind!r})'


# The order below is the manual demo's order. step4 (concat-msvcf) and step5
# (annotate-variant) are in fact siblings -- both depend only on step3, and the
# manual runs have started them seconds apart -- but they are sequenced here
# because a strict chain is sufficient for the demo and much easier to reason
# about on failure.
IGG_STAGE_LIST = [
    Stage('aggregate-gvcf', 'analysis', 'step1: ingest gVCFs into per-shard cohort/census'),
    Stage('aggregate-census', 'analysis', 'step2: aggregate census per version and shard'),
    Stage('count-subshards', 'local', 'collect subshard counts produced by step2'),
    Stage('generate-msvcf', 'analysis', 'step3: msVCF, ML filtering, reduced msVCF, PGEN'),
    Stage('concat-msvcf', 'analysis', 'step4: concatenate per output format'),
    Stage('annotate-variant', 'analysis', 'step5: annotate site VCF'),
]

DEFAULT_DEMO = {
    'batch_ids': '1',
    'shard_ids': '88-89',
    'version_id': '1',
    'chrom_ids': '20',
    'concat_options': 'reduced-site-vcf,reduced-vcf,pgen,site-vcf,vcf',
    'analysis_instance_tier': 'economy',
}

DEFAULT_POLL_INTERVAL = 60
DEFAULT_STAGE_TIMEOUT = 5400      # 90 min; measured stages run 17-22 min
DEFAULT_RUN_TIMEOUT = 5 * 3600


class StageFailure(Exception):
    """Raised when a stage reaches a terminal failure or times out."""

    def __init__(self, stage_name, reason, analyses=None):
        self.stage_name = stage_name
        self.reason = reason
        self.analyses = analyses or []
        super().__init__(f'stage "{stage_name}" {reason}')


# ------- orchestrator -------

class IggOrchestrator:

    def __init__(self, project_config_path, project_data_folder, analysis_json_folder,
                 demo=None, poll_interval=DEFAULT_POLL_INTERVAL,
                 stage_timeout=DEFAULT_STAGE_TIMEOUT, run_timeout=DEFAULT_RUN_TIMEOUT,
                 dry_run=False, submit_main=None, ica_client=None, sleep=None,
                 run_metadata=None):
        self.project_config_path = project_config_path
        self.project_data_folder = project_data_folder
        self.analysis_json_folder = analysis_json_folder
        self.demo = dict(DEFAULT_DEMO)
        if demo:
            self.demo.update(demo)
        self.poll_interval = poll_interval
        self.stage_timeout = stage_timeout
        self.run_timeout = run_timeout
        self.dry_run = dry_run

        # injectable for tests
        self._submit_main = submit_main or submit.main
        self._sleep = sleep or time.sleep

        self.project_config = utils.read_json(project_config_path)
        self.project_name = self.project_config['ica_job_project']['name']
        self.project_id = self.project_config['ica_job_project']['id']
        self.region_code = self.project_config['ica_region']['code']
        self.run_id = utils.get_unique_id(use_timestamp=True)
        self.started_at = time.time()
        self.ledger = {
            'run_id': self.run_id,
            'ica_region': self.region_code,
            'project_name': self.project_name,
            'project_id': self.project_id,
            'popgen_cli_version': utils.get_package_version(),
            'demo': self.demo,
            'stages': [],
        }
        if run_metadata:
            self.ledger.update(run_metadata)

        self.ica_client = ica_client
        if self.ica_client == None and not dry_run:
            self.ica_client = utils.ICAClient(
                api_key=self.project_config['ica_api_key'],
                retry_runner=utils.RetryRunner())
            self.ica_client._set_cache_using_project_config(self.project_config)

    # ---- output ----

    def log(self, message):
        elapsed = int(time.time() - self.started_at)
        print(f'[igg {elapsed // 60:3d}m{elapsed % 60:02d}s] {message}', flush=True)

    def ledger_path(self):
        return os.path.join(self.analysis_json_folder, f'igg-run-{self.run_id}.json')

    def save_ledger(self):
        utils.write_json(self.ledger, self.ledger_path(), indent=2)

    # ---- submission ----

    def submit_args_for(self, stage, extra):
        args = [
            '--input-project-data-folder-path', self.project_data_folder,
            '--input-project-config-file-path', self.project_config_path,
            '--output-analysis-json-folder-path', self.analysis_json_folder,
            '--step-name', stage.name,
            '--analysis-instance-tier', self.demo['analysis_instance_tier'],
        ]
        for key, value in extra:
            args.extend([key, str(value)])
        if self.dry_run:
            args.extend(['--dry-run', 'true'])
        return args

    def _analysis_json_files(self):
        if not os.path.isdir(self.analysis_json_folder):
            return set()
        return {f for f in os.listdir(self.analysis_json_folder)
                if f.endswith('.json') and not f.startswith('igg-run-')}

    def submit_stage(self, stage, extra_args_list):
        """Submit one stage and return [(analysis_name, analysis_id), ...].

        Analysis ids are read back from the per-analysis JSON that
        submit.submit_jobs writes, so the id recorded here is exactly the id ICA
        returned for this invocation.
        """
        if self.dry_run:
            # A dry run must not create anything. submit.submit_jobs creates the
            # cohort-census and msvcf-version projects before it checks its own
            # --dry-run flag, so it is not called here; the arguments are parsed
            # instead, which validates them without touching ICA.
            analyses = []
            for index, extra in enumerate(extra_args_list):
                argv = self.submit_args_for(stage, extra)
                submit.parse_args(argv)
                self.log(f'{stage.name}: would submit '
                         f'{" ".join(str(x) for x in argv[6:])}')
                analyses.append({'analysis_name': f'{stage.name}-dry-run-{index}',
                                 'analysis_id': None, 'dry_run': True})
            return analyses

        before = self._analysis_json_files()
        for extra in extra_args_list:
            self._submit_main(self.submit_args_for(stage, extra))
        new_files = sorted(self._analysis_json_files() - before)

        analyses = []
        for filename in new_files:
            details = utils.read_json(os.path.join(self.analysis_json_folder, filename))
            analyses.append({
                'analysis_name': filename[:-len('.json')],
                'analysis_id': details.get('id'),
                'analysis_json': filename,
            })
        return analyses

    # ---- polling ----

    def poll_stage(self, stage, analyses):
        """Poll every analysis of a stage until all succeed, one fails, or timeout."""
        if self.dry_run:
            self.log(f'{stage.name}: dry-run, not polling')
            return

        pending = {a['analysis_id']: a for a in analyses if a['analysis_id']}
        missing = [a for a in analyses if not a['analysis_id']]
        if missing:
            raise StageFailure(
                stage.name,
                f'submission returned no analysis id for '
                f'{[a["analysis_name"] for a in missing]}',
                analyses)

        last_status = {}
        warned_unknown = set()
        stage_started = time.time()

        while pending:
            if time.time() - stage_started > self.stage_timeout:
                raise StageFailure(
                    stage.name,
                    f'timed out after {int(time.time() - stage_started)}s '
                    f'(limit {self.stage_timeout}s) with '
                    f'{len(pending)} analysis(es) not finished',
                    list(pending.values()))
            if time.time() - self.started_at > self.run_timeout:
                raise StageFailure(
                    stage.name,
                    f'run timeout of {self.run_timeout}s exceeded',
                    list(pending.values()))

            for analysis_id in list(pending):
                entry = pending[analysis_id]
                details = self.ica_client.get_analysis(
                    project_name=self.project_name, analysis_id=analysis_id)
                status = details.get('status')
                outcome = utils.classify_analysis_status(status)
                entry['status'] = status
                entry['outcome'] = outcome

                # only report a status when it changes, so a long stage stays quiet
                if last_status.get(analysis_id) != status:
                    last_status[analysis_id] = status
                    self.log(f'{stage.name} {entry["analysis_name"]} '
                             f'[{analysis_id}] -> {status}')

                if outcome == utils.ANALYSIS_SUCCESS:
                    del pending[analysis_id]
                elif outcome == utils.ANALYSIS_FAILURE:
                    entry['diagnostics'] = self.capture_diagnostics(analysis_id, details)
                    raise StageFailure(
                        stage.name, f'analysis reached terminal state "{status}"', [entry])
                elif outcome == utils.ANALYSIS_UNKNOWN and analysis_id not in warned_unknown:
                    warned_unknown.add(analysis_id)
                    # never treated as success; the stage timeout is the backstop
                    self.log(f'*WARNING* {stage.name} {analysis_id} reports unrecognized '
                             f'status "{status}"; continuing to poll, will not pass')

            if pending:
                self._sleep(self.poll_interval)

    def capture_diagnostics(self, analysis_id, details):
        """Everything ICA will tell us about a failure, without extra guessing."""
        diagnostics = {
            'status': details.get('status'),
            'summary': details.get('summary'),
            'start_date': details.get('startDate'),
            'end_date': details.get('endDate'),
            'pipeline': (details.get('pipeline') or {}).get('code'),
        }
        path = os.path.join(self.analysis_json_folder,
                            f'igg-run-{self.run_id}.failed.{analysis_id}.json')
        try:
            utils.write_json(details, path, indent=2)
            diagnostics['details_file'] = path
        except Exception:
            pass
        return diagnostics

    # ---- local stage ----

    def run_count_subshards(self):
        """Collect the per-shard subshard counts that step2 produced.

        Equivalent of count_subshards() in demo/dragen-igg/3.submit.sh, using the
        ICA helpers instead of shelling out to icav2.
        """
        version_id = self.demo['version_id']
        shard_ids = utils.parse_int_range_str(self.demo['shard_ids'])
        prefix = self.project_name[:-len(MANAGED_NAME_SUFFIX)]
        msvcf_project = f'{prefix}-msvcf-version-{version_id}'

        local_dir = os.path.join(self.analysis_json_folder, f'subshard-{self.run_id}')
        url_list, path_list = [], []
        for shard_id in shard_ids:
            for basename in ('dragen.shard.num-subshards.csv', 'dragen.subshards.stats.tsv'):
                url_list.append(
                    f'ica://{msvcf_project}/data/global-census/shard-{shard_id}/{basename}')
                path_list.append(os.path.join(local_dir, f'shard-{shard_id}.{basename}'))

        if self.dry_run:
            self.log(f'count-subshards: dry-run, would download {len(url_list)} files '
                     f'from "{msvcf_project}"')
            # a placeholder count of 1 per shard so the remaining plan can be shown
            return {'subshard_counts': {str(s): 1 for s in shard_ids}, 'dry_run': True}

        downloader = utils.ICADownloader(self.ica_client)
        downloader.download(ica_url_list=url_list, local_path_list=path_list)

        subshard_dir = os.path.join(self.project_data_folder, 'version-subshard')
        utils.prep_output_folder(subshard_dir)
        counts_path = os.path.join(subshard_dir, f'version-{version_id}.subshards.csv')
        stats_path = os.path.join(subshard_dir, f'version-{version_id}.subshards.stats.tsv')

        counts = {}
        with open(counts_path, 'w') as fout:
            for shard_id in shard_ids:
                src = os.path.join(local_dir, f'shard-{shard_id}.dragen.shard.num-subshards.csv')
                with open(src) as fin:
                    text = fin.read()
                fout.write(text)
                for line in text.splitlines():
                    fields = line.split(',')
                    if len(fields) >= 2 and fields[0].strip() == str(shard_id):
                        counts[str(shard_id)] = int(fields[1])
        with open(stats_path, 'w') as fout:
            for shard_id in shard_ids:
                src = os.path.join(local_dir, f'shard-{shard_id}.dragen.subshards.stats.tsv')
                with open(src) as fin:
                    fout.write(fin.read())

        if not counts:
            raise StageFailure(
                'count-subshards',
                f'no subshard counts were found for version {version_id} in '
                f'"{msvcf_project}"; step3 cannot be submitted')

        # upload both files back into the jobs project, as the manual demo does
        uploader = utils.ICAUploader(self.ica_client)
        uploader.upload(
            local_dir=subshard_dir,
            ica_url=f'ica://{self.project_name}/meta/version-subshard/',
            region_name=self.region_code,
            storage_bundle_name=self.project_config['ica_storage_bundle']['bundleName'],
            storage_configuration_name=None)

        self.log(f'count-subshards: subshards per shard = {counts}')
        return {'subshard_counts': counts, 'counts_file': counts_path}

    # ---- stage argument construction ----

    def extra_args_for(self, stage, state):
        version_id = self.demo['version_id']
        if stage.name == 'aggregate-gvcf':
            return [[('--batch-ids', self.demo['batch_ids']),
                     ('--shard-ids', self.demo['shard_ids']),
                     ('--track-variants', 'false')]]
        if stage.name == 'aggregate-census':
            return [[('--version-ids', version_id),
                     ('--shard-ids', self.demo['shard_ids'])]]
        if stage.name == 'generate-msvcf':
            counts = state.get('subshard_counts') or {}
            out = []
            for shard_id in utils.parse_int_range_str(self.demo['shard_ids']):
                num = int(counts.get(str(shard_id), 0))
                if num == 0:
                    self.log(f'generate-msvcf: shard {shard_id} has 0 subshards, skipping')
                    continue
                out.append([('--version-ids', version_id),
                            ('--shard-ids', shard_id),
                            ('--subshard-ids', f'1-{num}')])
            return out
        if stage.name == 'concat-msvcf':
            return [[('--version-ids', version_id),
                     ('--chrom-ids', self.demo['chrom_ids']),
                     ('--concat-options', self.demo['concat_options'])]]
        if stage.name == 'annotate-variant':
            return [[('--version-ids', version_id),
                     ('--chrom-ids', self.demo['chrom_ids'])]]
        raise Exception(f'no submit arguments defined for stage "{stage.name}"')

    # ---- run ----

    def run(self):
        self.log(f'run {self.run_id} region {self.region_code} '
                 f'project {self.project_name} ({self.project_id})')
        self.log(f'demo parameters {json.dumps(self.demo, sort_keys=True)}')
        utils.prep_output_folder(self.analysis_json_folder)

        state = {}
        for stage in IGG_STAGE_LIST:
            record = {'stage': stage.name, 'kind': stage.kind,
                      'started_at': datetime.datetime.utcnow().isoformat() + 'Z'}
            self.ledger['stages'].append(record)
            self.log(f'--- {stage.name}: {stage.description}')
            try:
                if stage.kind == 'local':
                    state.update(self.run_count_subshards() or {})
                    record['result'] = 'SUCCEEDED'
                else:
                    extra_args_list = self.extra_args_for(stage, state)
                    if not extra_args_list:
                        raise StageFailure(
                            stage.name, 'nothing to submit; upstream produced no work')
                    analyses = self.submit_stage(stage, extra_args_list)
                    record['analyses'] = analyses
                    self.save_ledger()
                    verb = 'planned' if self.dry_run else 'submitted'
                    self.log(f'{stage.name}: {verb} {len(analyses)} analysis(es)')
                    self.poll_stage(stage, analyses)
                    record['result'] = 'SUCCEEDED'
            except StageFailure as failure:
                record['result'] = 'FAILED'
                record['reason'] = failure.reason
                record['analyses'] = failure.analyses or record.get('analyses')
                record['ended_at'] = datetime.datetime.utcnow().isoformat() + 'Z'
                self.save_ledger()
                self.report_failure(failure)
                return 1
            except Exception as exc:
                record['result'] = 'ERROR'
                record['reason'] = f'{type(exc).__name__}: {exc}'
                record['ended_at'] = datetime.datetime.utcnow().isoformat() + 'Z'
                self.save_ledger()
                self.report_failure(StageFailure(stage.name, record['reason']))
                return 1

            record['ended_at'] = datetime.datetime.utcnow().isoformat() + 'Z'
            self.save_ledger()
            self.log(f'{stage.name}: SUCCEEDED')

        self.ledger['result'] = 'SUCCEEDED'
        self.save_ledger()
        self.log('')
        self.log(f'IGG demo SUCCEEDED. run id {self.run_id}')
        self.log(f'  region          {self.region_code}')
        self.log(f'  jobs project    {self.project_name} ({self.project_id})')
        self.log(f'  stages          {", ".join(s.name for s in IGG_STAGE_LIST)}')
        self.log(f'  run record      {self.ledger_path()}')
        return 0

    def report_failure(self, failure):
        self.ledger['result'] = 'FAILED'
        self.save_ledger()
        print('', flush=True)
        print('*ERROR* IGG demo FAILED', flush=True)
        print(f'  run id          {self.run_id}', flush=True)
        print(f'  region          {self.region_code}', flush=True)
        print(f'  jobs project    {self.project_name} ({self.project_id})', flush=True)
        print(f'  failing stage   {failure.stage_name}', flush=True)
        print(f'  reason          {failure.reason}', flush=True)
        for entry in failure.analyses or []:
            print(f'  analysis        {entry.get("analysis_name")}', flush=True)
            print(f'    id            {entry.get("analysis_id")}', flush=True)
            print(f'    status        {entry.get("status")}', flush=True)
            diagnostics = entry.get('diagnostics') or {}
            if diagnostics.get('summary'):
                print(f'    summary       {diagnostics["summary"]}', flush=True)
            if diagnostics.get('details_file'):
                print(f'    details       {diagnostics["details_file"]}', flush=True)
            if entry.get('analysis_id'):
                print(f'    inspect       icav2 projectanalyses get '
                      f'{entry["analysis_id"]} --project-id {self.project_id}', flush=True)
        print(f'  run record      {self.ledger_path()}', flush=True)
        print('', flush=True)


# ------- non-interactive setup -------

def setup(args):
    """Non-interactive equivalent of "popgen-cli dragen-igg config".

    Reuses ICAConfig so the project, folders, pipeline, activation code and
    uploaded config file are produced by exactly the same code as the
    interactive flow; only the prompts are replaced by deterministic choices.
    """
    config = utils.ICAConfig(workflow_name=WORKFLOW_NAME, dragen_version_list=[])

    api_key = args.ica_api_key or os.environ.get('ICA_API_KEY')
    if not api_key:
        api_key = getpass.getpass('ICA API key (input will not display): ').strip()
    if not api_key:
        sys.exit('*ERROR* ICA API key is empty. '
                 'Pass --ica-api-key or set ICA_API_KEY.')
    config.ica_api_key = api_key
    config.ica_client = utils.ICAClient(
        api_key=api_key,
        base_url=f'https://{args.ica_server_url}/ica/rest/api',
        retry_runner=utils.RetryRunner())
    config.enable_byob = False
    config.ica_storage_configuration = None

    # region, resolved through the same filter the interactive flow applies
    supported = {short: code for code, (_, short)
                 in config.supported_ica_aws_region_map.items()}
    if args.region not in supported:
        sys.exit(f'*ERROR* region "{args.region}" is not supported. '
                 f'Supported: {sorted(supported)}')
    region_code = supported[args.region]
    regions = [r for r in config.ica_client.get_regions() if r['code'] == region_code]
    if not regions:
        sys.exit(f'*ERROR* region "{args.region}" ({region_code}) is not available in '
                 f'your ICA subscription. Please contact the ICA team.')
    config.ica_region = regions[0]

    bundles = [b for b in config.ica_client.get_storage_bundles()
               if b['region']['id'] == config.ica_region['id']]
    if not bundles:
        sys.exit(f'*ERROR* no storage bundle in region "{args.region}". '
                 f'Please contact the ICA team.')
    config.ica_storage_bundle = bundles[0]

    # project: reuse a compatible managed project, else create one
    run_id = args.run_id or utils.get_unique_id(use_timestamp=True)[-4:]
    date_str = datetime.datetime.utcnow().strftime('%Y%m%d')
    version = utils.get_package_version()

    project_details = None
    if not args.new_project and args.purpose != 'customer':
        candidates = find_managed_projects(
            config.ica_client, purpose=args.purpose, region_short_name=args.region)
        candidates = [c for c in candidates if c.get('active', True)]
        if candidates:
            project_details = sorted(candidates, key=lambda p: p.get('timeCreated', ''))[-1]
            print(f'Reusing managed project "{project_details["name"]}" '
                  f'({project_details["id"]})')

    if project_details == None:
        project_name = args.project_name or managed_project_name(
            args.region, args.purpose, date_str, run_id)
        valid, reason = _validate_project_name(project_name)
        if not valid:
            sys.exit(f'*ERROR* project name "{project_name}" is invalid: {reason}')
        print(f'Creating managed project "{project_name}"')
        project_details = config.ica_client.get_or_create_project(
            project_name=project_name,
            region_name=config.ica_region['code'],
            storage_bundle_name=config.ica_storage_bundle['bundleName'],
            storage_configuration_name=None,
            technical_tags=managed_technical_tags(
                args.purpose, args.region, run_id, version),
            short_description=(f'popgen-cli {WORKFLOW_NAME} {args.purpose} '
                               f'(automation-managed)'))
    config.ica_job_project = project_details

    config.config_ica_project_folders()

    storages = config.ica_client.get_analysis_storages(
        project_name=config.ica_job_project['name'])
    preferred = [s for s in storages if s['name'] == args.analysis_storage] or storages
    if not preferred:
        sys.exit(f'*ERROR* no analysis storage available in project '
                 f'"{config.ica_job_project["name"]}".')
    config.ica_analysis_storage = preferred[0]
    print(f'Analysis storage "{config.ica_analysis_storage["name"]}"')

    config.config_ica_analysis_pipeline()

    activation_codes = config.ica_client.get_cwl_activation_codes(
        project_name=config.ica_job_project['name'],
        pipeline_name=config.ica_analysis_pipeline['pipeline']['code'])
    if not activation_codes:
        sys.exit(f'*ERROR* no entitled activation code matches pipeline '
                 f'"{config.ica_analysis_pipeline["pipeline"]["code"]}" in region '
                 f'"{args.region}". Please contact the ICA team.')
    config.ica_analysis_activation_code = activation_codes[0]
    print(f'Activation code "{config.ica_analysis_activation_code["pipelineBundle"]["name"]}"')

    config.save_upload_project_config()

    print(f'\nSetup complete.')
    print(f'  region          {args.region} ({config.ica_region["code"]})')
    print(f'  jobs project    {config.ica_job_project["name"]} '
          f'({config.ica_job_project["id"]})')
    print(f'  docker image    {config.ica_analysis_docker_image}')
    print(f'  config file     {config.config_file_local_path}')
    print(f'\nNext: popgen-cli {WORKFLOW_NAME} demo')
    return 0


def _validate_project_name(name):
    supported_chars = string.ascii_lowercase + string.digits + '-'
    if len(name) < 8 or len(name) > 64:
        return False, 'shorter than 8 or longer than 64 characters'
    if not name.endswith(MANAGED_NAME_SUFFIX):
        return False, f'does not end with "{MANAGED_NAME_SUFFIX}"'
    if name[0] not in string.ascii_lowercase:
        return False, 'does not start with a lowercase letter'
    for char in name:
        if char not in supported_chars:
            return False, f'character "{char}" is not supported'
    return True, ''


def find_project_config(project_data_folder):
    secret_dir = os.path.join(project_data_folder, 'secret')
    if not os.path.isdir(secret_dir):
        return None
    candidates = sorted(f for f in os.listdir(secret_dir)
                        if f.startswith('project-config.') and f.endswith('.json'))
    if not candidates:
        return None
    return os.path.join(secret_dir, candidates[-1])


def upload_project_data(project_config_path, project_data_folder):
    """Equivalent of demo/dragen-igg/2.upload.sh: every project-data subfolder
    except "secret" is uploaded to /meta/ of the jobs project."""
    project_config = utils.read_json(project_config_path)
    ica_client = utils.ICAClient(
        api_key=project_config['ica_api_key'], retry_runner=utils.RetryRunner())
    ica_client._set_cache_using_project_config(project_config)
    uploader = utils.ICAUploader(ica_client)
    project_name = project_config['ica_job_project']['name']
    region_code = project_config['ica_region']['code']
    bundle_name = project_config['ica_storage_bundle']['bundleName']

    uploaded = []
    for entry in sorted(os.listdir(project_data_folder)):
        if entry == 'secret':
            continue
        local_dir = os.path.join(project_data_folder, entry)
        if not os.path.isdir(local_dir):
            continue
        uploader.upload(
            local_dir=local_dir,
            ica_url=f'ica://{project_name}/meta/{entry}/',
            region_name=region_code,
            storage_bundle_name=bundle_name,
            storage_configuration_name=None)
        uploaded.append(entry)
    return uploaded


# ------- customer input preflight -------

def read_sample_manifest(manifest_path):
    """Read the customer CSV contract used by the lifecycle commands.

    Keeping this separate from IGG's generated batch files means a customer never
    has to edit project-data internals.  All errors are accumulated so a bad
    cohort is rejected before an ICA analysis can be created.
    """
    if not os.path.isfile(manifest_path):
        raise ValueError(f'sample manifest does not exist: {manifest_path}')
    with open(manifest_path, newline='') as fin:
        reader = csv.DictReader(fin)
        columns = tuple(reader.fieldnames or ())
        missing = [name for name in REQUIRED_MANIFEST_COLUMNS if name not in columns]
        if missing:
            raise ValueError('sample manifest is missing required column(s): ' +
                             ', '.join(missing))
        rows = []
        errors = []
        seen = set()
        for line, row in enumerate(reader, start=2):
            sample_id = (row.get('sample_id') or '').strip()
            gvcf = (row.get('gvcf') or '').strip()
            gvcf_index = (row.get('gvcf_index') or '').strip()
            sex = (row.get('sex') or '').strip()
            if not sample_id:
                errors.append(f'line {line}: sample_id is empty')
            elif sample_id in seen:
                errors.append(f'line {line}: duplicate sample_id "{sample_id}"')
            else:
                seen.add(sample_id)
            if sample_id and not re.match(r'^[A-Za-z0-9][A-Za-z0-9._-]*$', sample_id):
                errors.append(f'line {line}: sample_id may contain only letters, numbers, dot, underscore, and hyphen')
            if sex not in {'1', '2', '0'}:
                errors.append(f'line {line}: sex must be 1 (male), 2 (female), or 0 (unknown)')
            if not gvcf.startswith('ica://'):
                errors.append(f'line {line}: gvcf must be an ica:// file URL')
            if not gvcf_index.startswith('ica://'):
                errors.append(f'line {line}: gvcf_index must be an ica:// file URL')
            if gvcf and not gvcf.endswith('.gvcf.gz'):
                errors.append(f'line {line}: gvcf must end in .gvcf.gz')
            if gvcf_index and not (gvcf_index == gvcf + '.tbi' or
                                   gvcf_index == gvcf + '.csi'):
                errors.append(f'line {line}: gvcf_index must be the matching .tbi or .csi')
            rows.append({'sample_id': sample_id, 'gvcf': gvcf,
                         'gvcf_index': gvcf_index, 'sex': sex})
    if not rows:
        errors.append('sample manifest has no samples')
    if errors:
        raise ValueError('invalid sample manifest:\n  ' + '\n  '.join(errors))
    return rows


def read_run_ledger(ledger_path):
    if not os.path.isfile(ledger_path):
        raise ValueError(f'prior run ledger does not exist: {ledger_path}')
    ledger = utils.read_json(ledger_path)
    samples = ledger.get('cohort_samples')
    if not isinstance(samples, list) or not samples:
        raise ValueError(f'prior ledger has no cohort_samples: {ledger_path}')
    if not ledger.get('project_config_path') or not ledger.get('template_project_data_folder'):
        raise ValueError(f'prior ledger lacks project configuration/template references: {ledger_path}')
    return ledger


def compose_cohort(manifest_path, previous_ledger_path=None):
    added = read_sample_manifest(manifest_path)
    if not previous_ledger_path:
        return {'samples': added, 'previous_count': 0, 'added_count': len(added),
                'final_count': len(added), 'source_ledger': None}
    previous = read_run_ledger(previous_ledger_path)
    old_samples = previous['cohort_samples']
    old_ids = {row['sample_id'] for row in old_samples}
    duplicate_ids = sorted(old_ids.intersection(row['sample_id'] for row in added))
    if duplicate_ids:
        raise ValueError('new manifest contains sample ID(s) already in prior cohort: ' +
                         ', '.join(duplicate_ids))
    return {'samples': old_samples + added, 'previous_count': len(old_samples),
            'added_count': len(added), 'final_count': len(old_samples) + len(added),
            'source_ledger': os.path.abspath(previous_ledger_path),
            'project_config_path': previous['project_config_path'],
            'template_project_data_folder': previous['template_project_data_folder'],
            'region': previous.get('region')}


def generate_customer_project_data(samples, template_project_data_folder,
                                   project_config_path, output_project_data_folder):
    """Build a private run tree from shipped static metadata and customer inputs."""
    if os.path.exists(output_project_data_folder):
        raise ValueError(f'run folder already exists; refusing to overwrite: {output_project_data_folder}')
    if not os.path.isdir(template_project_data_folder):
        raise ValueError(f'packaged template project-data folder does not exist: {template_project_data_folder}')
    for required in ('config/shards.txt', 'config/gvcf-version.txt', 'config/ref.csv',
                     'config/annodb.txt', 'config/low-conf.bed'):
        if not os.path.isfile(os.path.join(template_project_data_folder, required)):
            raise ValueError(f'packaged template is missing {required}; extract the regional IGG demo archive')
    if not os.path.isfile(project_config_path):
        raise ValueError(f'project configuration does not exist: {project_config_path}')

    os.makedirs(output_project_data_folder, mode=0o700)
    for folder in ('config',):
        shutil.copytree(os.path.join(template_project_data_folder, folder),
                        os.path.join(output_project_data_folder, folder))
    for folder in ('secret',):
        os.makedirs(os.path.join(output_project_data_folder, folder), mode=0o700)
    shutil.copy2(project_config_path,
                 os.path.join(output_project_data_folder, 'secret',
                              os.path.basename(project_config_path)))

    batch_dir = os.path.join(output_project_data_folder, 'batch-gvcf')
    version_batch_dir = os.path.join(output_project_data_folder, 'version-batch')
    version_gender_dir = os.path.join(output_project_data_folder, 'version-gender')
    for folder in (batch_dir, version_batch_dir, version_gender_dir):
        os.makedirs(folder, exist_ok=True)
    with open(os.path.join(batch_dir, 'batch-1.gvcfs.csv'), 'w') as fout:
        for sample in samples:
            fout.write(f'{sample["gvcf"]},{sample["gvcf_index"]}\n')
    with open(os.path.join(version_batch_dir, 'version-1.batches.txt'), 'w') as fout:
        fout.write('1\n')
    with open(os.path.join(version_gender_dir, 'version-1.genders.tsv'), 'w') as fout:
        fout.write('#FID\tIID\tSEX\n')
        for sample in samples:
            # IGG/PLINK uses the sample name carried by the gVCF header. The
            # customer must set sample_id to the name in that gVCF header.
            fout.write(f'{sample["sample_id"]}\t{sample["sample_id"]}\t{sample["sex"]}\n')
    return output_project_data_folder


def validate_customer_manifest(manifest_path, project_config_path=None):
    """Validate schema locally and, when configured, prove ICA inputs readable."""
    rows = read_sample_manifest(manifest_path)
    result = {'manifest': os.path.abspath(manifest_path), 'sample_count': len(rows),
              'sample_ids': [row['sample_id'] for row in rows], 'ica_readable': False}
    if project_config_path:
        config = utils.read_json(project_config_path)
        client = utils.ICAClient(api_key=config['ica_api_key'], retry_runner=utils.RetryRunner())
        client._set_cache_using_project_config(config)
        # ICADownloader.presign obtains read-only temporary credentials and calls
        # HeadObject via AWSClient; it is therefore an actual readability check,
        # not merely ICA URL syntax validation.
        urls = [value for row in rows for value in (row['gvcf'], row['gvcf_index'])]
        expected_region = config['ica_region']['code']
        for url in urls:
            _, project_name, _ = utils.parse_url(url)
            project = client.get_project(project_name)
            if project is None:
                raise ValueError(f'ICA input project does not exist or is not accessible: {project_name}')
            actual_region = (project.get('region') or {}).get('code')
            if actual_region and actual_region != expected_region:
                raise ValueError(f'ICA input project {project_name} is in region {actual_region}; '
                                 f'configured run is in {expected_region}')
        utils.ICADownloader(client).presign(urls)
        result['ica_readable'] = True
        result['region'] = expected_region
        result['jobs_project'] = config['ica_job_project']['name']
    return result


# ------- CLI -------

def parse_setup_args(sys_args):
    parser = argparse.ArgumentParser(
        usage=f'\n  {utils.get_package_name()} {WORKFLOW_NAME} setup [args]\n\n'
              f'description:\n'
              f'  non-interactive one-time setup of an IGG job project\n'
              f'  (interactive alternative: {utils.get_package_name()} '
              f'{WORKFLOW_NAME} config)\n',
        formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument('--region', required=True,
                        help='popgen region short name, e.g. ape2 (Taiwan), use1')
    parser.add_argument('--purpose', default='demo', choices=SUPPORTED_PURPOSE_LIST,
                        help='purpose recorded in the managed project name and tags')
    parser.add_argument('--ica-api-key', default=None,
                        help='ICA API key; defaults to $ICA_API_KEY, else prompted')
    parser.add_argument('--ica-server-url', default=utils.ICAConfig.default_ica_server_url)
    parser.add_argument('--analysis-storage', default='Small')
    parser.add_argument('--project-name', default=None,
                        help='override the generated managed project name')
    parser.add_argument('--run-id', default=None)
    parser.add_argument('--new-project', action='store_true',
                        help='always create a new managed project instead of reusing one')
    return parser.parse_args(sys_args)


def parse_demo_args(sys_args):
    parser = argparse.ArgumentParser(
        usage=f'\n  {utils.get_package_name()} {WORKFLOW_NAME} demo [args]\n\n'
              f'description:\n'
              f'  run and supervise the complete IGG demo: upload, submit each\n'
              f'  stage, poll until it succeeds, then submit the next stage\n',
        formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument('--input-project-data-folder-path', default='project-data')
    parser.add_argument('--input-project-config-file-path', default=None,
                        help='defaults to the newest project-data/secret/project-config.*.json')
    parser.add_argument('--output-analysis-json-folder-path', default='project-analyses')
    parser.add_argument('--batch-ids', default=DEFAULT_DEMO['batch_ids'])
    parser.add_argument('--shard-ids', default=DEFAULT_DEMO['shard_ids'])
    parser.add_argument('--version-id', default=DEFAULT_DEMO['version_id'])
    parser.add_argument('--chrom-ids', default=DEFAULT_DEMO['chrom_ids'])
    parser.add_argument('--concat-options', default=DEFAULT_DEMO['concat_options'])
    parser.add_argument('--analysis-instance-tier',
                        default=DEFAULT_DEMO['analysis_instance_tier'])
    parser.add_argument('--poll-interval', type=int, default=DEFAULT_POLL_INTERVAL)
    parser.add_argument('--stage-timeout', type=int, default=DEFAULT_STAGE_TIMEOUT)
    parser.add_argument('--run-timeout', type=int, default=DEFAULT_RUN_TIMEOUT)
    parser.add_argument('--skip-upload', action='store_true',
                        help='skip the project-data upload (already uploaded)')
    parser.add_argument('--dry-run', action='store_true',
                        help='print the stage plan and submit nothing')
    return parser.parse_args(sys_args)


def parse_validate_args(sys_args):
    parser = argparse.ArgumentParser(
        usage=f'\n  {utils.get_package_name()} {WORKFLOW_NAME} validate --manifest samples.csv [args]\n',
        description=('Validate customer sample IDs, duplicate IDs, gVCF/index pairs, '
                     'and (with --project-config) actual ICA read access before submission.'))
    parser.add_argument('--manifest', required=True,
                        help='CSV with sample_id,gvcf,gvcf_index,sex columns')
    parser.add_argument('--project-config', default=None,
                        help='generated project-config JSON; enables ICA readability validation')
    return parser.parse_args(sys_args)


def parse_run_args(sys_args):
    parser = argparse.ArgumentParser(
        usage=f'\n  {utils.get_package_name()} {WORKFLOW_NAME} run --manifest samples.csv [args]\n',
        description=('Prepare an isolated persistent customer project, validate inputs, '
                     'generate the IGG metadata, and run the complete cohort.'))
    parser.add_argument('--manifest', required=True,
                        help='CSV: sample_id,gvcf,gvcf_index,sex; sample_id must match the gVCF header sample name')
    parser.add_argument('--region', default=None,
                        help='supported PopGen region; inferred from --add-to when adding samples')
    parser.add_argument('--template-project-data-folder', default=None,
                        help='project-data folder from the downloaded regional IGG demo archive')
    parser.add_argument('--add-to', default=None,
                        help='prior successful or partial IGG run ledger; adds samples as a full N+M rerun')
    parser.add_argument('--analysis-instance-tier', default=DEFAULT_DEMO['analysis_instance_tier'])
    parser.add_argument('--poll-interval', type=int, default=DEFAULT_POLL_INTERVAL)
    parser.add_argument('--stage-timeout', type=int, default=DEFAULT_STAGE_TIMEOUT)
    parser.add_argument('--run-timeout', type=int, default=DEFAULT_RUN_TIMEOUT)
    parser.add_argument('--dry-run', action='store_true',
                        help='validate and print the plan without creating ICA resources or submitting')
    parser.add_argument('--output-root', default='popgen-igg-runs')
    return parser.parse_args(sys_args)


def main_setup(sys_args):
    return setup(parse_setup_args(sys_args))


def main_demo(sys_args):
    args = parse_demo_args(sys_args)

    project_data_folder = args.input_project_data_folder_path
    project_config_path = (args.input_project_config_file_path
                           or find_project_config(project_data_folder))
    if not project_config_path or not os.path.isfile(project_config_path):
        sys.exit(f'*ERROR* no project config file found under '
                 f'"{os.path.join(project_data_folder, "secret")}". '
                 f'Run "{utils.get_package_name()} {WORKFLOW_NAME} setup --region <region>" '
                 f'(or "{WORKFLOW_NAME} config") first.')

    if not args.skip_upload and not args.dry_run:
        print(f'Uploading "{project_data_folder}" to the jobs project /meta/ folder ...')
        uploaded = upload_project_data(project_config_path, project_data_folder)
        print(f'Uploaded: {", ".join(uploaded)}')

    orchestrator = IggOrchestrator(
        project_config_path=project_config_path,
        project_data_folder=project_data_folder,
        analysis_json_folder=args.output_analysis_json_folder_path,
        demo={
            'batch_ids': args.batch_ids,
            'shard_ids': args.shard_ids,
            'version_id': args.version_id,
            'chrom_ids': args.chrom_ids,
            'concat_options': args.concat_options,
            'analysis_instance_tier': args.analysis_instance_tier,
        },
        poll_interval=args.poll_interval,
        stage_timeout=args.stage_timeout,
        run_timeout=args.run_timeout,
        dry_run=args.dry_run)
    return orchestrator.run()


def main_validate(sys_args):
    args = parse_validate_args(sys_args)
    try:
        result = validate_customer_manifest(args.manifest, args.project_config)
    except (ValueError, OSError, KeyError, Exception) as error:
        # The command has no submission path.  A non-zero preflight is deliberate:
        # callers must correct input rather than continue with a partial cohort.
        print(f'*ERROR* customer preflight failed: {error}', file=sys.stderr)
        return 2
    print('Customer sample manifest is valid.')
    print(f'  samples         {result["sample_count"]}')
    print(f'  ICA readable    {"yes" if result["ica_readable"] else "not checked (no --project-config)"}')
    if result.get('region'):
        print(f'  region          {result["region"]}')
    return 0


def main_run(sys_args):
    args = parse_run_args(sys_args)
    try:
        if args.add_to:
            cohort = compose_cohort(args.manifest, args.add_to)
            prior_region = cohort.get('region')
            if args.region and prior_region and args.region != prior_region:
                raise ValueError(f'--region {args.region} does not match prior run region {prior_region}')
            region = args.region or prior_region
            template_folder = (args.template_project_data_folder or
                               cohort['template_project_data_folder'])
            project_config_path = None
        else:
            samples = read_sample_manifest(args.manifest)
            cohort = {'samples': samples, 'previous_count': 0,
                      'added_count': len(samples), 'final_count': len(samples),
                      'source_ledger': None}
            region = args.region
            template_folder = args.template_project_data_folder
            project_config_path = None
        if not region:
            raise ValueError('--region is required for a new cohort')
        if not template_folder:
            raise ValueError('--template-project-data-folder is required for a new cohort')
        if args.dry_run:
            # Check local template presence and manifest composition without
            # provisioning projects, checking credentials, or submitting work.
            for required in ('config/shards.txt', 'config/gvcf-version.txt',
                             'config/ref.csv', 'config/annodb.txt', 'config/low-conf.bed'):
                if not os.path.isfile(os.path.join(template_folder, required)):
                    raise ValueError(f'packaged template is missing {required}')
            print(f'Plan: full cohort of {cohort["final_count"]} sample(s); '
                  f'previous={cohort["previous_count"]}, added={cohort["added_count"]}; '
                  f'region={region}; no ICA resources created and no analyses submitted.')
            return 0

        # Every customer cohort receives a distinct persistent ICA project so
        # derived cohort/output project names cannot collide across full reruns.
        setup_argv = ['--region', region, '--purpose', 'customer', '--new-project']
        result = main_setup(setup_argv)
        if result:
            return result
        project_config_path = find_project_config('project-data')
        if not project_config_path:
            raise ValueError('setup completed but project-data/secret contains no project config')

        # Perform the remote read check before generating/uploading the run tree.
        config = utils.read_json(project_config_path)
        if config['ica_region']['code'] != region_code_for_short_name(region):
            raise ValueError(f'project config region {config["ica_region"]["code"]} does not match {region}')
        urls = [v for sample in cohort['samples'] for v in
                (sample['gvcf'], sample['gvcf_index'])]
        client = utils.ICAClient(api_key=config['ica_api_key'], retry_runner=utils.RetryRunner())
        client._set_cache_using_project_config(config)
        for url in urls:
            _, project_name, _ = utils.parse_url(url)
            project = client.get_project(project_name)
            if project is None:
                raise ValueError(f'ICA input project does not exist or is not accessible: {project_name}')
            actual_region = (project.get('region') or {}).get('code')
            if actual_region and actual_region != config['ica_region']['code']:
                raise ValueError(f'ICA input project {project_name} is in region {actual_region}; '
                                 f'configured run is in {config["ica_region"]["code"]}')
        utils.ICADownloader(client).presign(urls)

        run_id = utils.get_unique_id(use_timestamp=True)
        os.makedirs(args.output_root, exist_ok=True)
        run_root = os.path.join(args.output_root, run_id)
        project_data_folder = os.path.join(run_root, 'project-data')
        generate_customer_project_data(cohort['samples'], template_folder,
                                       project_config_path, project_data_folder)
        analysis_folder = os.path.join(run_root, 'project-analyses')
        uploaded = upload_project_data(project_config_path, project_data_folder)
        workflow = IggOrchestrator(
            project_config_path=project_config_path,
            project_data_folder=project_data_folder,
            analysis_json_folder=analysis_folder,
            demo={'batch_ids': '1', 'shard_ids': '1-102', 'version_id': '1',
                  'chrom_ids': '1-26',
                  'analysis_instance_tier': args.analysis_instance_tier},
            poll_interval=args.poll_interval, stage_timeout=args.stage_timeout,
            run_timeout=args.run_timeout,
            run_metadata={
                'workflow_type': 'customer-full-cohort',
                'cohort_samples': cohort['samples'],
                'previous_sample_count': cohort['previous_count'],
                'added_sample_count': cohort['added_count'],
                'final_sample_count': cohort['final_count'],
                'source_ledger': cohort.get('source_ledger'),
                'region': region,
                'source_manifest_path': os.path.abspath(args.manifest),
                'project_config_path': os.path.abspath(project_config_path),
                'template_project_data_folder': os.path.abspath(template_folder),
                'customer_project': config['ica_job_project']['name'],
                'uploaded_metadata_folders': uploaded,
            })
        print(f'Customer cohort size: previous {cohort["previous_count"]} + '
              f'added {cohort["added_count"]} = {cohort["final_count"]}.')
        print('This run processes the complete cohort; it does not claim incremental compute.')
        return workflow.run()
    except Exception as error:
        print(f'*ERROR* customer run failed: {error}',
              file=sys.stderr)
        return 2


def region_code_for_short_name(region_short_name):
    config = utils.ICAConfig(workflow_name=WORKFLOW_NAME, dragen_version_list=[])
    for code, (_, short_name) in config.supported_ica_aws_region_map.items():
        if short_name == region_short_name:
            return code
    raise ValueError(f'unsupported PopGen region: {region_short_name}')
