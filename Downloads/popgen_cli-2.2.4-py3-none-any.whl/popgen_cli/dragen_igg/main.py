from __future__ import annotations
import popgen_cli.utils.utils as utils
import popgen_cli.dragen_igg.config as config
import popgen_cli.dragen_igg.submit as submit
import popgen_cli.dragen_igg.orchestrator as orchestrator
import argparse
import sys


def parse_args(sys_args):

    usage = f"""
  {utils.get_package_name()} dragen-igg [action] [args]

description:
  manage Iterative Gvcf Genotyper workflow

available actions:
  config      config Iterative Gvcf Genotyper project and pipeline (interactive)
  setup       config Iterative Gvcf Genotyper project and pipeline (non-interactive)
  submit      submit Iterative Gvcf Genotyper analysis
  demo        run and supervise the complete Iterative Gvcf Genotyper demo
  validate    validate a customer sample manifest before any submission
  run         run IGG on customer data; --add-to runs the full N+M cohort

"""

    parser = argparse.ArgumentParser(usage=usage)
    parser.add_argument(
        'action', metavar='action',
        help='actions to manage Iterative Gvcf Genotyper workflow, see actions above')

    return parser.parse_args(sys_args[1:2])


def main(sys_args):

    args = parse_args(sys_args)

    if args.action == 'config':
        config.main(sys_args[2:])

    elif args.action == 'setup':
        sys.exit(orchestrator.main_setup(sys_args[2:]))

    elif args.action == 'submit':
        submit.main(sys_args[2:])

    elif args.action == 'demo':
        sys.exit(orchestrator.main_demo(sys_args[2:]))

    elif args.action == 'validate':
        sys.exit(orchestrator.main_validate(sys_args[2:]))

    elif args.action == 'run':
        sys.exit(orchestrator.main_run(sys_args[2:]))

    else:
        print(f'*ERROR* dragen-igg workflow action "{args.action}" is not supported.')
