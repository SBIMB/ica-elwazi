"""Version information."""
__version__ = "2.2.4"
__git_version__ = "2.2.4"
__docker_tag__ = "2.2.4"
